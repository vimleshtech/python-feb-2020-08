a= 44
b =5

c =a+b

print(c)
