
#print('hello')

'''
print('world')
print('bye')
'''

"""
test code 
print(555566)
"""


print('end of code ')
