
a = input()
b = input('enter data ')

print(type(a))
print(type(b))


#type cast

c       =int(a) + int(b)

print(c)


#format
print('sum of a and b is c')
print('sum of {} and {} is {}'.format(a,b,c))
print('sum of {1} and {0} is {2}'.format(a,b,c))

#print('sum of {1} and {0} is {}'.format(a,b,c)) #error






