a = int(input('etner data :'))
b = int(input('etner data :'))

if a>b:
    print('a is greater')
else:
    print('b is greater')



